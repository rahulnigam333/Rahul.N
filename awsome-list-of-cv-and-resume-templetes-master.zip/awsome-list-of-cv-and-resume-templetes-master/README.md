# awsome-list-of-cv-and-resume-templetes
A list of awesome criculium vitae(CV) and resume in latex and word format.
I have tried to gather first editions and unique ones only.
<!-- <p align='center'>
<img src = '/overall_pi_chart.png' height="300px">  
<img src = '/overall_histogram.png' height="4300px">
</p> -->
 
 
 ### Table of contents
 
 
1. [A note on ATS](#a-note-on-ats)
2. [Latex Templetes](#latex)
3. [Word Templetes](#word)
4. [Resume Review](#cv-review)

#### A note on ATS
 <details>
  <summary>About ATS (Applicant Tracking System)-Friendly resume/CV (Click to expand!) </summary>
* Basically if you believe your resume is going to get read by an ATS system prior to get read by human, be cautios about Latex or even PDF files in some cases. While you cannot be sure that your CV will be friendly to an ATS, you can reduce the risk by taking a few steps:

  
**Note:** This is usually not the case when you are applying to Universities.
 
1. test your file with basic available tools. example pdftotext tool in python 
install (terminal) : 
 ```
 pip install pdftotext
 pdftotext ~/path/to/cv.pdf -
 
 ```
 This will show you a conversion, and everything should look readable and in the right place, no wiered characters, no misplacements. 
 this does not provide any gurrentee as some ATS cannot even open a pdf! 
 
2. Pass your CV to some job application and see if the website can read details in your CV correctly. platforms like brassring, myworkdayjobs, etc.

3. (for ATS) avoid using rare fonts, graphics, icons. ( While these makes CV more abstract and readable, ATS is not designed to understand these.)
3. (for ATS) Use word templete (and even upload the word file) as they are the safe side, I will put some templetes at the end of this. 
 
</details>



### Latex
 
*#* | *Type* | *Name* | *format* | *preview* | 
:---: | :---: |:--- | :---: | :---: | 
1	| multipage - OneColumn	| [Awesome-CV](https://github.com/posquit0/Awesome-CV) | latex |  <img src="https://raw.githubusercontent.com/posquit0/Awesome-CV/master/examples/resume-0.png" alt-="CV example" width="300px"/> |
2	| multipage - OneColumn	| [sc932](https://github.com/sc932/resume) | latex |  <img src="images/sc932.png" alt-="sc932" width="300px"/> |
3	| multipage - OneColumn	| [jankapunkt - Classic](https://github.com/jankapunkt/latexcv) | latex |  <img src="https://raw.githubusercontent.com/jankapunkt/latexcv/master/docs/media/classic.png" alt-="jankapunkt" width="300px"/> |
4	| multipage - OneColumn	| [jankapunkt - Modern](https://github.com/jankapunkt/latexcv) | latex |  <img src="https://raw.githubusercontent.com/jankapunkt/latexcv/master/docs/media/modern.png" alt-="jankapunkt" width="300px"/> |
5	| multipage - OneColumn	| [jankapunkt - Infographocs](https://github.com/jankapunkt/latexcv) | latex |  <img src="https://raw.githubusercontent.com/jankapunkt/latexcv/master/docs/media/infographics.png" alt-="jankapunkt" width="300px"/> |
6	| multipage - TwoColumn	| [jankapunkt - TwoColumn](https://github.com/jankapunkt/latexcv) | latex |  <img src="https://raw.githubusercontent.com/jankapunkt/latexcv/master/docs/media/two_column.png" alt-="jankapunkt" width="300px"/> |
7	| multipage - Sidebar	| [jankapunkt - Sidebar](https://github.com/jankapunkt/latexcv) | latex |  <img src="https://raw.githubusercontent.com/jankapunkt/latexcv/master/docs/media/sidebar.png" alt-="jankapunkt" width="300px"/> |
8	| multipage - OneColumn	| [jankapunkt - RwoLayout](https://github.com/jankapunkt/latexcv) | latex |  <img src="https://raw.githubusercontent.com/jankapunkt/latexcv/master/docs/media/rows.png" alt-="jankapunkt" width="300px"/> |
9	| multipage - OneColumn	| [jankapunkt - Sidebar Left](https://github.com/jankapunkt/latexcv) | latex |  <img src="https://raw.githubusercontent.com/jankapunkt/latexcv/master/docs/media/sidebarleft.png" alt-="jankapunkt" width="300px"/> |
10	| OnePage - OneColumn	| [McDowell CV](https://github.com/dnl-blkv/mcdowell-cv) | latex |  <img src="https://raw.githubusercontent.com/dnl-blkv/mcdowell-cv/master/McDowell_CV.png" alt-="jankapunkt" width="300px"/> |
11	| multipage - OneColumn	| [cimichi CV](https://github.com/cmichi/latex-template-collection) | latex |  <img src="images/cimichi.png" alt-="jankapunkt" width="300px"/> |
12	| multipage - OneColumn	| [yaac-another-awsome CV](https://github.com/darwiin/yaac-another-awesome-cv) | latex |  <img src="https://raw.githubusercontent.com/darwiin/yaac-another-awesome-cv/master/example/preview/cv1.jpeg" alt-="jankapunkt" width="300px"/> |
13	| multipage - multiColumn	| [liantze AltaCV](https://github.com/liantze/AltaCV) | latex |  <img src="https://raw.githubusercontent.com/liantze/AltaCV/master/mmayer.png" alt-="jankapunkt" width="300px"/> |
14	| multipage - multiColumn	| [limeCV ](https://github.com/opieters/limecv) | latex |  <img src="https://raw.githubusercontent.com/opieters/limecv/master/images/cv.png" alt-="jankapunkt" width="300px"/> |
15	| multipage - multiColumn	| [Friggeri CV ](https://www.overleaf.com/latex/templates/friggeri-cv-template/hmnchbfmjgqh) | latex |  <img src="images/frig.jpeg" alt-="jankapunkt" width="300px"/> |
16	| multipage - oneColumn	| [zachscrivena CV ](https://github.com/zachscrivena/simple-resume-cv) | latex |  <img src="https://raw.githubusercontent.com/zachscrivena/simple-resume-cv/master/Miscellaneous/CV-01.png" alt-="jankapunkt" width="300px"/> |
17	| multipage - oneColumn	| [ billryan CV ](https://github.com/billryan/resume) | latex |  <img src="https://user-images.githubusercontent.com/1292567/62409353-3fecfc00-b608-11e9-8e83-84962912c956.png" alt-="jankapunkt" width="300px"/> |
18	| onepage - oneColumn	| [ ice1000 CV ](https://github.com/ice1000/resume) | latex |  <img src="images/ice1000.png" alt-="jankapunkt" width="300px"/> |
19	| multipage - oneColumn	| [ liweitianux CV ](https://github.com/liweitianux/resume) | latex |  <img src="images/liweitianux.png" alt-="jankapunkt" width="300px"/> |
20	| multipage - oneColumn	| [ raphink CV ](https://github.com/raphink/CV) | latex |  <img src="images/raphink.png" alt-="jankapunkt" width="300px"/> |
21	| multipage - twoColumn	| [ 20 seconds CV ](https://github.com/spagnuolocarmine/TwentySecondsCurriculumVitae-LaTex) | latex |  <img src="https://raw.githubusercontent.com/spagnuolocarmine/TwentySecondsCurriculumVitae-LaTex/master/Twenty-Seconds_cv_icons.jpg" alt-="jankapunkt" width="300px"/> |
22	| multipage - twoColumn	| [ Smart Fancy CV ](https://github.com/neoben/smart-fancy-latex-cv) | latex |  <img src="https://camo.githubusercontent.com/7daf6cb16e490677864f9343b0f84b561def9d2b/687474703a2f2f7777772e6361726d696e6562656e65646574746f2e6e65742f5f646f776e6c6f6164732f736d6172742d66616e63792d6c617465782d63762d73637265656e73686f742e6a7067" alt-="jankapunkt" width="300px"/> |
23	| multipage - twoColumn	| [ Orbit CV ](https://github.com/mvarela/orbit-cv) | latex |  <img src="https://raw.githubusercontent.com/mvarela/orbit-cv/master/output_samples/colorscheme6.png" alt-="jankapunkt" width="300px"/> |
24	| multipage - oneColumn	| [ gboeing CV ](https://github.com/gboeing/cv) | latex |  <img src="images/gboeing.png" alt-="jankapunkt" width="300px"/> |
25	| multipage - twoColumn	| [ fanzeyi CV ](https://github.com/fanzeyi/cv) | latex |  <img src="images/fanzeyi.png" alt-="jankapunkt" width="300px"/> |
26	| multipage - ineColumn	| [ leouieda CV ](https://github.com/leouieda/cv) | latex |  <img src="images/leouieda.png" alt-="jankapunkt" width="300px"/> |
27	| multipage - twoColumn	| [ martinothamar CV ](https://github.com/martinothamar/CV-Latex-Template) | latex |  <img src="https://raw.githubusercontent.com/martinothamar/CV-Latex-Template/master/CV.png" alt-="jankapunkt" width="300px"/> |
28	| multipage - twoColumn	| [ roycoding CV ](https://github.com/roycoding/fancyresume) | latex |  <img src="images/roycoding.png" alt-="jankapunkt" width="300px"/> |
29	| multipage - oneColumn	| [ roald87 CV ](https://github.com/Roald87/xelatex-cv-roald) | latex |  <img src="https://raw.githubusercontent.com/Roald87/xelatex-cv-roald/master/cv-roald-example.png" alt-="jankapunkt" width="300px"/> |
30	| multipage - oneColumn	| [ Material v2 CV ](https://github.com/amng/MaterialCv) | latex |  <img src="https://raw.githubusercontent.com/amng/MaterialCv/master/images/preview2.png" alt-="jankapunkt" width="300px"/> |
31	| multipage - oneColumn	| [ Material v1 CV ](https://github.com/amng/MaterialCv) | latex |  <img src="https://raw.githubusercontent.com/amng/MaterialCv/master/images/preview.PNG" alt-="jankapunkt" width="300px"/> |
32	| multipage - oneColumn	| [ cv4tw simple CV ](https://github.com/Cicatrice/cv4tw) | latex |  <img src="images/simple.png" alt-="jankapunkt" width="300px"/> |
33	| multipage - oneColumn	| [ cv4tw sharp CV ](https://github.com/Cicatrice/cv4tw) | latex |  <img src="images/sharp.png" alt-="jankapunkt" width="300px"/> |
34	| onepage - oneColumn	| [ cv4tw compact CV ](https://github.com/Cicatrice/cv4tw) | latex |  <img src="images/compact.png" alt-="jankapunkt" width="300px"/> |
35	| multipage - oneColumn	| [ seignort CV ](https://github.com/seignovert/cv) | latex |  <img src="https://raw.githubusercontent.com/seignovert/cv/master/cv/cv-0.jpg" alt-="jankapunkt" width="300px"/> |
36	| multipage - oneColumn	| [ eivindml CV ](https://github.com/eivindml/cv) | latex |  <img src="images/eivin.png" alt-="jankapunkt" width="300px"/> |
37	| multipage - oneColumn	| [ GironsLopez CV ](https://github.com/GironsLopez/gironslopez-cv) | latex |  <img src="images/GironsLopez.png" alt-="jankapunkt" width="300px"/> |
38	| multipage - oneColumn	| [ eivindml CV ](https://github.com/xu-cheng/cv) | latex |  <img src="images/JianXu.png" alt-="jankapunkt" width="300px"/> |
39	| multipage - oneColumn	| [ cecilesauder CV ](https://github.com/cecilesauder/CV_LaTeX) | latex |  <img src="https://github.com/cecilesauder/CV_LaTeX/blob/master/screen.png" alt-="jankapunkt" width="300px"/> |
40	| multipage - oneColumn	| [ agonzalezro CV ](https://github.com/agonzalezro/Curriculum-Vitae) | latex |  <img src="images/agonzalezro.png" alt-="jankapunkt" width="300px"/> |
41	| multipage - oneColumn	| [ mcchran CV ](https://github.com/mcchran/lean_cv) | latex |  <img src="images/mcchran.png" alt-="jankapunkt" width="300px"/> |
42	| multipage - oneColumn	| [ isteves CV ](https://github.com/isteves/resume) | latex |  <img src="https://raw.githubusercontent.com/isteves/resume/master/images/cv-pdf.PNG" alt-="jankapunkt" width="300px"/> |
43	| multipage - oneColumn	| [ janvorisek CV ](https://github.com/janvorisek/minimal-latex-cv) | latex |  <img src="https://camo.githubusercontent.com/a7813d6482f6093d821e2f9b3c948d639ac78fc8/68747470733a2f2f6a616e2e766f726973656b2e6d652f696d616765732f6d61696e2d312e6a7067" alt-="jankapunkt" width="300px"/> |
44	| multipage - oneColumn	| [ jchodera CV ](https://github.com/jchodera/latex-cv) | latex |  <img src="images/jchodera.png" alt-="jankapunkt" width="300px"/> |
45	| multipage - oneColumn	| [ qwhxm CV ](https://github.com/qwhxm/1.5-column-cv) | latex |  <img src="https://raw.githubusercontent.com/qwhxm/1.5-column-cv/master/example-1/cv-example-1.png" alt-="jankapunkt" width="300px"/> |
46	| multipage - oneColumn	| [ gbmj timeline CV ](https://github.com/gbmj/gbmj-timeline-cv) | latex |  <img src="https://raw.githubusercontent.com/gbmj/gbmj-timeline-cv/master/sample-cv-p1n.png" alt-="jankapunkt" width="300px"/> |
47	| multipage - oneColumn	| [ thoughteer neat CV ](https://github.com/thoughteer/neat-cv) | latex |  <img src="images/thoughteer.png" alt-="jankapunkt" width="300px"/> |
48	| multipage - oneColumn	| [ saidziani CV ](https://github.com/saidziani/CV-Template) | latex |  <img src="images/saidziani.png" alt-="jankapunkt" width="300px"/> |
49	| multipage - oneColumn	| [ Pseudomanifold CV ](https://github.com/Pseudomanifold/latex-cv/) | latex |  <img src="images/Pseudomanifold.png" alt-="jankapunkt" width="300px"/> |
50	| multipage - oneColumn	| [ adarshbarik CV ](https://github.com/Adarsh-Barik/MinimalMaterialCV) | latex |  <img src="images/adarshbarik.png" alt-="jankapunkt" width="300px"/> |
51	| multipage - oneColumn	| [ bobok CV ](https://github.com/alexboboc/AlexBobocCV) | latex |  <img src="images/bobok.png" alt-="jankapunkt" width="300px"/> |
52	| multipage - oneColumn	| [ latex ninga modern CV ](https://github.com/latex-ninja/modern-simple-cv) | latex |  <img src="https://raw.githubusercontent.com/latex-ninja/hipster-cv/master/previews/modern-simple-cv.png" alt-="jankapunkt" width="300px"/> |
53	| onepage - twoColumn	| [ transducer CV ](https://github.com/transducer/CV-and-Cover-Letter-in-LaTeX) | latex |  <img src="images/transducer.png" alt-="jankapunkt" width="300px"/> |
54	| multipage - oneColumn	| [ mkearney CV ](https://github.com/mkearney/CV) | latex |  <img src="images/mkearney.png" alt-="jankapunkt" width="300px"/> |
55	| multipage - oneColumn	| [ andywiecko CV ](https://github.com/andywiecko/MultiLangCV) | latex |  <img src="images/andywiecko.png" alt-="jankapunkt" width="300px"/> |
56	| multipage - oneColumn	| [ avivace CV ](https://github.com/avivace/j2-resume) | latex |  <img src="https://raw.githubusercontent.com/avivace/j2-resume/master/.meta/pdf_sample.png" alt-="jankapunkt" width="300px"/> |
57	| onepage - oneColumn	| [ Template for Software Engineer CV ](https://www.overleaf.com/latex/examples/resume-template-for-software-engineer/fvsqzcybnwdn) | latex |  <img src="images/7344.jpeg" alt-="jankapunkt" width="300px"/> |
58	| multipage - oneColumn	| [ A Customised CurVe CV ](https://www.overleaf.com/latex/templates/a-customised-curve-cv/mvmbhkwsnmwv) | latex |  <img src="images/15436.jpeg" alt-="jankapunkt" width="300px"/> |
59	| multipage - oneColumn	| [ Scismic's CV ](https://www.overleaf.com/latex/templates/scismics-recommended-cv-template-for-biotech-and-pharma-jobs/hbnkjrjnnpjz) | latex |  <img src="images/15432.jpeg" alt-="jankapunkt" width="300px"/> |
60	| multipage - oneColumn	| [ sb2nov CV ](https://github.com/sb2nov/resume) | latex |  <img src="https://raw.githubusercontent.com/sb2nov/resume/master/resume_preview.png" alt-="jankapunkt" width="300px"/> |
61	| multipage - oneColumn	| [ Awsome with image CV ](https://www.overleaf.com/latex/templates/awesome-cv-cover-letter/hzvvsbxccjhz) | latex |  <img src="images/11040.jpeg" alt-="jankapunkt" width="300px"/> |
62	| multipage - oneColumn	| [ Jakub Kúdela CV ](https://www.overleaf.com/latex/templates/resume/rysrqppxyvdg) | latex |  <img src="images/5312.jpeg" alt-="jankapunkt" width="300px"/> |
63	| multipage - oneColumn	| [ cies CV ](https://github.com/cies/resume) | latex |  <img src="images/cies.png" alt-="jankapunkt" width="300px"/> |


<!-- other : 
https://github.com/rgeirhos/academic-cv-publications
https://github.com/joede/modern-cv-style-letter
https://github.com/hacksalot/HackMyResume
https://github.com/saadq/resumake.io
https://github.com/prat0318/json_resume
https://github.com/dyweb/awesome-resume-for-chinese
 -->
 
### Word

*#* | *Type* | *Name* | *format* | *preview* | 
:---: | :---: |:--- | :---: | :---: | 
1	| singlepage, multipage - OneColumn	| [Wonsulting-CV](https://docs.google.com/document/d/1cnea3rniQWDA2t6SdNxXlAtzNs1YFRkS3qrgdoJAe18/edit) | word |  <img src="images/won.png" alt-="CV example" width="300px"/> |
2	|do a PR!	|  | word |  <img src="https://www.clipartmax.com/png/full/112-1125405_document-microsoft-word-icon-microsoft-word-icon-png.png" alt-="sc932" width="120px"/> |

### CV Review 
* If you want a resume/CV comments give send me your CV at my email. I have CE/CS/ECE background, So cannot make advanced comments for other majors. 

```
email: [mygithubid]@gmail.com
```

### Acknowledgment
* Templete is from awesome-deep-text-detection-recognition's list.
